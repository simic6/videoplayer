package com.example.videoplayer;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.SimpleExoPlayer;
import com.google.android.exoplayer2.PlaybackParameters;

public class MainActivity extends AppCompatActivity {

    private ExoPlayer player;
    private PlayerView playerView;
    private SeekBar seekBarRed, seekBarGreen, seekBarBlue, seekBarSpeed;
    private Button applyColorButton, muteButton;
    private LinearLayout layout;
    private TextView speedLabel;
    private boolean isMuted = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        playerView = findViewById(R.id.playerView);
        seekBarRed = findViewById(R.id.seekBarRed);
        seekBarGreen = findViewById(R.id.seekBarGreen);
        seekBarBlue = findViewById(R.id.seekBarBlue);
        seekBarSpeed = findViewById(R.id.seekBarSpeed);
        applyColorButton = findViewById(R.id.applyColorButton);
        muteButton = findViewById(R.id.muteButton);
        layout = findViewById(R.id.layout); // The background layout to change color
        speedLabel = findViewById(R.id.speedLabel);

        // Initialize ExoPlayer
        player = new SimpleExoPlayer.Builder(this).build();
        playerView.setPlayer(player);

        // Load a sample video (replace with your video URL or path)
        MediaItem mediaItem = MediaItem.fromUri("android.resource://" + getPackageName() + "/" + R.raw.sample_video);
        player.setMediaItem(mediaItem);
        player.prepare();

        // Set button click listener to apply background color
        applyColorButton.setOnClickListener(view -> applyBackgroundColor());

        // Set up the speed SeekBar listener (only allows faster playback)
        seekBarSpeed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                // Map SeekBar progress to a playback speed value (min 1x, max 5x)
                float speed = (progress / 10f) + 1f; // Range from 1x to 5x
                player.setPlaybackParameters(new PlaybackParameters(speed));
                speedLabel.setText("Speed: " + speed + "x");
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                // No action needed here
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                // No action needed here
            }
        });

        // Set up the mute button to toggle mute/unmute
        muteButton.setOnClickListener(view -> toggleMute());
    }

    // Method to apply the background color based on SeekBar values
    private void applyBackgroundColor() {
        // Get RGB values from SeekBars
        int red = seekBarRed.getProgress();
        int green = seekBarGreen.getProgress();
        int blue = seekBarBlue.getProgress();

        // Apply the background color
        int color = Color.rgb(red, green, blue);
        layout.setBackgroundColor(color); // Set the background color of the layout
    }

    // Method to toggle mute and unmute the video
    private void toggleMute() {
        if (isMuted) {
            // Unmute the video
            player.setVolume(1f);
            muteButton.setText("Mute");
        } else {
            // Mute the video
            player.setVolume(0f);
            muteButton.setText("Unmute");
        }
        isMuted = !isMuted;
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (player != null) {
            player.release(); // Release player when activity is paused
        }
    }
}
