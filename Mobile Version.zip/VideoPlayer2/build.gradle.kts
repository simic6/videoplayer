// build.gradle.kts (Project-level)

plugins {
    id("com.android.application") version "8.8.0" apply false
    id("org.jetbrains.kotlin.android") version "1.7.10" apply false
}

buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        // Use proper Kotlin and Gradle plugin classpaths
        classpath("com.android.tools.build:gradle:8.8.0")  // Update AGP version if needed
        classpath("org.jetbrains.kotlin:kotlin-gradle-plugin:1.7.10")  // Update Kotlin plugin version
    }
}
