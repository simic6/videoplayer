const videoPlayer = document.getElementById("videoPlayer");
const playPauseBtn = document.getElementById("playPauseBtn");
const restartBtn = document.getElementById("restartBtn");
const skipBackBtn = document.getElementById("skipBackBtn");
const skipForwardBtn = document.getElementById("skipForwardBtn");
const fileInput = document.getElementById("fileInput");
const redFilterBtn = document.getElementById("redFilterBtn");
const greenFilterBtn = document.getElementById("greenFilterBtn");
const blueFilterBtn = document.getElementById("blueFilterBtn");
const resetFilterBtn = document.getElementById("resetFilterBtn");

let videoFileURL = ''; // Store the video file URL

// Load the selected video file into the video player
fileInput.addEventListener("change", function() {
    const file = fileInput.files[0];
    if (file) {
        videoFileURL = URL.createObjectURL(file);
        const videoSource = document.getElementById("videoSource");
        videoSource.src = videoFileURL;
        videoPlayer.load();
        videoPlayer.play();
        playPauseBtn.textContent = "Pause"; // Change button to Pause
    }
});

// Play/Pause the video
playPauseBtn.addEventListener("click", function() {
    if (videoPlayer.paused) {
        videoPlayer.play();
        playPauseBtn.textContent = "Pause";
    } else {
        videoPlayer.pause();
        playPauseBtn.textContent = "Play";
    }
});

// Restart the video
restartBtn.addEventListener("click", function() {
    videoPlayer.currentTime = 0; // Go to the beginning
    videoPlayer.play(); // Start playing
    playPauseBtn.textContent = "Pause"; // Change button to Pause
});

// Skip back 5 seconds
skipBackBtn.addEventListener("click", function() {
    videoPlayer.currentTime -= 5;
});

// Skip forward 5 seconds
skipForwardBtn.addEventListener("click", function() {
    videoPlayer.currentTime += 5;
});

// Apply Red Filter
redFilterBtn.addEventListener("click", function() {
    videoPlayer.style.filter = 'sepia(100%) hue-rotate(-50deg)'; // A red filter
});

// Apply Green Filter
greenFilterBtn.addEventListener("click", function() {
    videoPlayer.style.filter = 'sepia(100%) hue-rotate(90deg)'; // A green filter
});

// Apply Blue Filter
blueFilterBtn.addEventListener("click", function() {
    videoPlayer.style.filter = 'sepia(100%) hue-rotate(180deg)'; // A blue filter
});

// Reset the filter
resetFilterBtn.addEventListener("click", function() {
    console.log("Resetting the filter...");
    videoPlayer.style.filter = 'none'; // Remove any filters applied
});
